# Bài Tập Tuần 1: Kiến Trúc Song Song & Thiết Kế Thuật Toán Song Song
## Môn học: IT5408 – Tính toán hiệu năng cao (HPC)

Thư mục chứa toàn bộ lời giải chi tiết, mã nguồn mô phỏng và kiểm chứng các bài toán trong file đề bài **`Week 1.pdf`**.

---

## 1. Cấu trúc thư mục

```text
week1/
├── Bao_cao_Bai_tap_Tuan_1.md    # Báo cáo lời giải chi tiết 12 bài tập (đầy đủ công thức LaTeX & bảng biểu)
├── simulations.py               # Script Python mô phỏng và kiểm chứng kết quả số học / thuật toán
├── README.md                    # File hướng dẫn này
└── .venv/                       # Môi trường ảo Python
```

---

## 2. Danh mục bài tập đã giải trong báo cáo

### PHẦN A – Kiến trúc song song và hiệu năng
* **Bài 1:** Định luật Amdahl – Tính Speedup tối đa với 95% song song trên 32 lõi ($S = 12.55\text{x}$) và vô hạn lõi ($S_{\max} = 20\text{x}$).
* **Bài 2:** Xác định tỉ lệ phần tuần tự tối đa ($s \le 0.2525\%$) để đạt Speedup = 80 trên 100 bộ xử lý.
* **Bài 3:** Phân loại Flynn cho GPU (SIMD/SIMT) và CPU đa lõi hỗ trợ lệnh vector AVX (MIMD toàn chip và SIMD trong từng lõi).
* **Bài 4:** Bốn nguyên nhân khiến kiến trúc bộ nhớ chia sẻ khó mở rộng lên hàng nghìn bộ xử lý (Băng thông bộ nhớ, Cache Coherence, Mạng liên kết phần cứng, Tranh chấp đồng bộ).
* **Bài 5:** Bảng phân biệt toàn diện giữa kiến trúc NUMA và Kiến trúc Bộ nhớ phân tán (Không gian địa chỉ, Cơ chế truy cập từ xa, Vai trò phần cứng & Lập trình viên).
* **Bài 6:** Bài toán mô phỏng dự báo thời tiết ($4 \times 10^9$ ô, 20,160 bước thời gian $\Rightarrow 1.6128 \times 10^{16}$ phép tính $\Rightarrow 186.67$ ngày tính toán).

### PHẦN B – Mô hình và thiết kế thuật toán song song
* **Bài 7:** Phân tích mô hình `mpirun -np 8 ./sim` theo kiến trúc SPMD (Single Program, Multiple Data).
* **Bài 8:** Phân tích sự cố của phép logic AND trên mô hình CRCW PRAM Arbitrary và đưa ra phản ví dụ cụ thể.
* **Bài 9:** Thuật toán tìm Max trên EREW PRAM (Cây nhị phân khử $T(n) = O(\log n), p = n/2$), và cải tiến 2 pha theo Định lý Brent để đạt tối ưu chi phí ($p = n/\log n, C(n) = O(n)$).
* **Bài 10:** Bài toán Broadcast trên CREW PRAM ($O(1)$) so với EREW PRAM (kỹ thuật *Growing by doubling*, $O(\log n)$ bước).
* **Bài 11:** Áp dụng kỹ thuật nhảy con trỏ (Pointer Jumping) trên danh sách liên kết $2 \to 4 \to 1 \to 3$ với bảng theo dõi chi tiết mảng `RANK` và `NEXT` qua từng bước.
* **Bài 12:** Phân tích sự đánh đổi chi phí trong thuật toán trộn song song bằng phân hoạch, chứng minh vì sao chọn kích thước khối $B = \log n$ là điểm cân bằng vàng (Cost-Optimal $O(n)$ và Thời gian $O(\log n)$).

---

## 3. Chạy script mô phỏng kiểm chứng

Để chạy lại script kiểm chứng số liệu bằng Python:

```bash
cd week1
source .venv/bin/activate
python3 simulations.py
```
